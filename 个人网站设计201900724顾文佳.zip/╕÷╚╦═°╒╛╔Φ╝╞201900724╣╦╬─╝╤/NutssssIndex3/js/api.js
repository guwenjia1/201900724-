let baseURL = "http://localhost:5000/api";

export default {
    test: 123
}