# NutssssIndex

这里是我个人主页的系列，我喜欢设计一下奇奇怪怪的东西练手，主打简约风格，并且独一无二，喜欢的欢迎点个 Star！有问题或者建议请留言 Issues！

## 目前作品列表

- [NutssssIndex](https://gitee.com/n0ts/NutssssIndex/tree/master/NutssssIndex)：我的第一个个人主页，简约风格无 Js 自适应

    [预览](https://n0ts.cn/nutssss1/)

    ![](https://images.gitee.com/uploads/images/2020/0525/000514_3cb0b6fa_2250179.png)

- [NutssssIndex2](https://gitee.com/n0ts/NutssssIndex/tree/master/NutssssIndex2)：Vscode 软件主题风格，简约自适应

    [预览](https://n0ts.cn/nutssss2/)

    ![](https://cdn.nutssss.cn/wp-content/uploads/2020/09/1600416929-2.png)

- [NutssssIndex3](https://gitee.com/n0ts/NutssssIndex/tree/master/NutssssIndex3)：开发中！敬请期待

    [预览](https://n0ts.cn/nutssss3/)

    ![](https://cdn.nutssss.cn/wp-content/uploads/2021/09/1632935351-Snipaste_2021-09-30_01-07-42.png)

- [个人简历](https://gitee.com/n0ts/NutssssIndex/tree/master/NutssssIndex4)：即将面试之前准备的个人简历

    [预览](https://me.n0ts.cn/)
    
    ![](https://cdn.nutssss.cn/wp-content/uploads/2021/09/1632935364-Snipaste_2021-09-30_01-06-57.png)

## QQ 群讨论

[坚果茶馆](https://jq.qq.com/?_wv=1027&k=Mh7ah6Dd)
