# NutssssIndex
简约个人主页、自适应  
[预览](https://n0ts.cn/nutssss1/)
![alt 预览图](https://images.gitee.com/uploads/images/2020/0525/000514_3cb0b6fa_2250179.png)

## 简介
两天时间写了一个练手作品  
不太想用别人的作品当做自己的个人主页了，心血来潮自己写了一个  
技术不是很好，但是还是写的很认真  
如有问题或建议欢迎提出  
自适应、简约、动画、无js  

## 使用方法
这还要看嘛？

## QQ群讨论

[坚果茶馆](https://jq.qq.com/?_wv=1027&k=Mh7ah6Dd)