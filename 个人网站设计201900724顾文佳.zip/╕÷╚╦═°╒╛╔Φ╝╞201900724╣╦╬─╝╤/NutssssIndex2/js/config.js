/*
 * @Author: N0ts
 * @Date: 2021-12-03 09:57:35
 * @LastEditTime: 2021-12-03 10:12:30
 * @Description: 配置
 * @FilePath: /NutssssIndex2/js/config.js
 * @Mail：mail@n0ts.cn
 */

export default {
    loveTime: Date.UTC(2018, 11, 19), // 恋爱时间
    giteeName: "N0ts" // Gitee 账号名
};
